python3 q1.py --model RNN -l 64 
python3 q1.py --model RNN -l 128

python3 q1.py --model LSTM -l 64 64
python3 q1.py --model LSTM -l 64 
python3 q1.py --model LSTM -l 128

python3 q1.py --model GRU -l 64 64
python3 q1.py --model GRU -l 64 
python3 q1.py --model GRU -l 128